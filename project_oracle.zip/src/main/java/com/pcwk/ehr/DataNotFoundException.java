package com.pcwk.ehr;

public class DataNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 274464773246046L;
	
	public void DateNotFoundException() {
		
	}
}
