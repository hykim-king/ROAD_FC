package com.pcwk.ehr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ehr01Application {

	public static void main(String[] args) {
		SpringApplication.run(Ehr01Application.class, args);
	}

}
